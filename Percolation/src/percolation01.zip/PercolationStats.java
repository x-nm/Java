/******************************************************************************
 *  Compilation:  javac PercolationStats.java
 *  Execution:    java PercolationStats N T 
 *  Dependencies: Percolation.java
 *
 *  This program takes the name of a file as a command-line argument.
 *  From that file, it
 *
 *    - Reads the grid size N of the percolation system.
 *    - Creates an N-by-N grid of sites (intially all blocked)
 *    - Reads in a sequence of sites (row i, column j) to open.
 *
 *  After each site is opened, it draws full sites in light blue,
 *  open sites (that aren't full) in white, and blocked sites in black,
 *  with with site (1, 1) in the upper left-hand corner.
 *
 ******************************************************************************/


import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.StdRandom;
import java.lang.Math; 

public class PercolationStats {
   private int n; //grid size
   private int t; //perform times
   private double[] perco_thres; //array stores the percolation threshold of each stimulation

   public PercolationStats(int N, int T)     // perform T independent experiments on an N-by-N grid
   {
   	   if (N <= 0 || T <= 0) throw new IllegalArgumentException("N or T is less than 1.");
   	   n = N;
   	   t = T;
   	   perco_thres = new double[t];
   	   for (int i = 0; i < t; i++)
   	   {
   	   	   Percolation perco = new Percolation(n);
   	   	   int count = 0;
   	   	   while (!perco.percolates())
   	   	   {
   	   	   	   int p, q;
   	   	   	   p = StdRandom.uniform(1, n+1);
   	   	   	   q = StdRandom.uniform(1, n+1);
   	   	   	   perco.open(p , q);
   	   	   	   count++;
   	   	   	   System.out.println(count);//
   	   	   }
   	   	   perco_thres[i] = count * 1.0 / n;
   	   } 
   }
   public double mean()                      // sample mean of percolation threshold
   {
   	   return StdStats.mean(perco_thres);
   }
   public double stddev()                    // sample standard deviation of percolation threshold
   {
   	   return StdStats.stddev(perco_thres);
   }
   public double confidenceLo()              // low  endpoint of 95% confidence interval
   {
   	   return mean() - 1.96 * stddev() / Math.sqrt(t);
   }
   public double confidenceHi()              // high endpoint of 95% confidence interval
   {
   	   return mean() + 1.96 * stddev() / Math.sqrt(t);
   }

   public static void main(String[] args)    // test client (described below)
   {
   	   int n = Integer.parseInt(args[0]);
   	   int t = Integer.parseInt(args[1]);
	   PercolationStats percoStats = new PercolationStats(n, t);
   	   System.out.println("mean = " + percoStats.mean());
   	   System.out.println("stddev = " + percoStats.stddev());
   	   System.out.println("95% confidence interval = " + percoStats.confidenceLo() + ", " + percoStats.confidenceHi());   	 
   }
}
